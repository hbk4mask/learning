package insight;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hive.HiveJdbc;
/**
 * Servlet implementation class DeepInsight
 */
@WebServlet("/DeepInsight")
public class DeepInsight extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeepInsight() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		HttpSession session = request.getSession(false);
		String tablename = request.getParameter("tname");
		System.out.println("360 tablename "+tablename);
		HiveJdbc hiveJbc=new HiveJdbc();
		List<String> columnList = new ArrayList<String>();
		try {
			columnList = hiveJbc.hiveDescribeCommandInvoker("describe "+tablename,2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<String> colToWork=new ArrayList<String>();
		List<String> stringColToWork=new ArrayList<String>();

		System.out.println(" columnList "+columnList.size());
		String numcols="";
		String stringcols="";
		
		System.out.println("printed cols fetched from hive");
		for(String record:columnList)
		{

			String[] col=record.split(",");
			if(col[1].equalsIgnoreCase("int"))
			{
				colToWork.add(col[0]);
				numcols=numcols+col[0];
				numcols=numcols+",";
			}
			
			if(col[1].equalsIgnoreCase("String"))
			{
				stringColToWork.add(col[0]);
				stringcols=stringcols+col[0];
				stringcols=stringcols+",";
			}

		}
		StringBuffer cols=new StringBuffer();
		
		
		System.out.println("making spark command for numerical data");
		int count=0;
		System.out.println(" ******** count "+count);
		for(String col:colToWork)
		{
			System.out.println("col "+col);
			cols.append("min("+col+")");
			cols.append(",");
			cols.append("max("+col+")");
			cols.append(",");
			
			cols.append("avg("+col+")");
			cols.append(",");
			
			
			cols.append("sum("+col+")");
			cols.append(",");
			
			cols.append("var_pop("+col+")");
			cols.append(",");
			
			cols.append("stddev_pop("+col+")");
			cols.append(",");
			count=count+6;
		}
		
		System.out.println("*********** first cols  "+cols.toString());
		cols.delete(cols.length()-1,cols.length());
		System.out.println("*********** integer cols  "+cols.toString());
		
// making spark command for string cols
		
		/*******************************************************************************************************************************************/	
		System.out.println("making spark command for numerical data");
		int count1=0;
		StringBuffer stringcolscommand=new StringBuffer();
		
		System.out.println(" ******** count "+count);
		for(String col:stringColToWork)
		{
			System.out.println("col "+col);
			
			try {
				
	            System.out.println("findling dintinct values");
	            String command="spark-submit --class hivecommand.HiveInput /root/inputfromlocal/scalawc.jar 'select distinct("+col+") from "+tablename+ "' "+col+"stats22";
				System.out.println("command "+command);
	            List<String> sparkResult= hiveJbc.hdfsCommandInvoker(command);


			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		// getting dintct values from hive
		List<String> distinctResult=new ArrayList<String> ();
		
		try {

			distinctResult= hiveJbc.hiveDescribeCommandInvoker("select * from occupationstats22",count);


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	/******************************************************************************************************************************************************/	
		try {
			
            System.out.println("mmmmmmmmmmmmmmmmmmmmmmmm4444444444444mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
			List<String> sparkResult= hiveJbc.hdfsCommandInvoker("spark-submit --class hivecommand.HiveInput /root/inputfromlocal/scalawc.jar 'select "+cols.toString()+" from "+tablename+ "'stats23");


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// adding logic to analyse categorical data
//		
//		try {
//			
//            System.out.println("mmmmmmmmmmmmmmmmmmmmmmmm4444444444444mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
//			List<String> sparkResult= hiveJbc.hdfsCommandInvoker("spark-submit --class hivecommand.HiveInput /root/inputfromlocal/scalawc.jar 'select "+stringcolscommand.toString()+" from "+tablename+ "' stats21");
//
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		List<String> statsResult=new ArrayList<String> ();
		try {

			statsResult= hiveJbc.hiveCommandInvoker("select * from stats19",count,numcols);


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(statsResult.toString());
		session.setAttribute("statsResult", statsResult);	
		session.setAttribute("tablename", tablename);	
		session.setAttribute("columnList", columnList);	
		request.getRequestDispatcher("/secondLevelInsight.jsp").forward(request, response);
	}


}