package view;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import hive.HiveJdbc;
import mysql.MysqlJdbc;
/**
 * Servlet implementation class FirstViewServlet
 */
@WebServlet("/FirstViewServlet")
public class FirstViewServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FirstViewServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


		HttpSession session = request.getSession(false);

		HiveJdbc hiveJdbc = new HiveJdbc();
		MysqlJdbc mysqlJdbc = new MysqlJdbc();
		String userid = request.getParameter("userid");
		System.out.println("360 view "+userid);
		String tablename=null;
		List<String> hiveCommandOutput=new ArrayList<String>();
		List<String> mysqlCommandOutput=new ArrayList<String>();
		List<String> dbtableslist=new ArrayList<String>();
		List<String> hivetableslist=new ArrayList<String>();
		String res=null;
		String[] tbname=userid.split("/");
		for(String a:tbname)
		{
			System.out.println("t value "+a);
		}

		String command=null;
		if(tbname[tbname.length-1].contains(".db"))
		{

			System.out.println("############# data base describe ##################");
			command="hadoop fs -ls /apps/hive/warehouse/"+tbname[tbname.length-1];	

			String host="192.168.154.131";
			String user="";
			String password="";
			//String command1="hadoop fs -ls /apps/hive/warehouse";
			System.out.println("command1 "+command);



			try{

				java.util.Properties config = new java.util.Properties(); 
				config.put("StrictHostKeyChecking", "no");
				JSch jsch = new JSch();
				Session session1=jsch.getSession(user, host, 22);
				session1.setPassword(password);
				session1.setConfig(config);
				session1.connect();
				System.out.println("Connected");

				Channel channel=session1.openChannel("exec");
				((ChannelExec)channel).setCommand(command);
				channel.setInputStream(null);
				((ChannelExec)channel).setErrStream(System.err);

				InputStream in=channel.getInputStream();
				channel.connect();
				byte[] tmp=new byte[1024];
				while(true)
				{
					while(in.available()>0)
					{
						int i=in.read(tmp, 0, 1024);
						if(i<0)break;
						System.out.println("console output");
						//System.out.print(new String(tmp, 0, i));

						dbtableslist.add(new String(tmp, 0, i));
					}
					if(channel.isClosed()){
						System.out.println("exit-status: "+channel.getExitStatus());
						break;
					}
					try{Thread.sleep(1000);}catch(Exception ee){}
				}
				channel.disconnect();
				session1.disconnect();
				System.out.println("DONE");
			}catch(Exception e){
				e.printStackTrace();
			}
			session.setAttribute("dbtableslist", dbtableslist);	

			request.getRequestDispatcher("/dboverview.jsp").forward(request, response);
		}
		else
		{
			System.out.println("############# table describe ##################");
			tablename=tbname[tbname.length-1];
			command="describe "+tbname[tbname.length-1];
			try {
				hiveCommandOutput=hiveJdbc.hiveDescribeCommandInvoker(command,2);
				System.out.println("$$$$$$$$$$$$4 size of hiveCommandOutput.size()"+hiveCommandOutput.size());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("$$$$$$$$$$ failed in hiveJdbc ");

				e.printStackTrace();
			}

			try {
				mysqlCommandOutput=mysqlJdbc.mysqlCommandInvoker("select PARAM_KEY,PARAM_VALUE from TABLE_PARAMS WHERE TBL_ID= (select TBL_ID from TBLS WHERE TBL_NAME='"+tbname[tbname.length-1]+"');");
				System.out.println("size of mysqlCommandOutput.size()"+mysqlCommandOutput.size());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// select * from TABLE_PARAMS WHERE TBL_ID= (select TBL_ID from TBLS WHERE TBL_NAME='unm_dup_parti');
			// select COLUMN_NAME,TYPE_NAME from COLUMNS_V2 where CD_ID = (select TBL_ID from TBLS WHERE TBL_NAME='unm_dup_parti');
			System.out.println("hiveCommandOutput "+hiveCommandOutput.size());
			System.out.println("mysqlCommandOutput "+mysqlCommandOutput.size());
			session.setAttribute("hiveCommandOutput", hiveCommandOutput);	
			session.setAttribute("mysqlCommandOutput", mysqlCommandOutput);	
			session.setAttribute("tablename", tablename);	


			request.getRequestDispatcher("/tableoverview.jsp").forward(request, response);

		}









	}

}
