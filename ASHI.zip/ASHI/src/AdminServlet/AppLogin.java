package AdminServlet;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import xxx.Tru;
/**
 * Servlet implementation class AppLogin
 */
@WebServlet("/AppLogin")
public class AppLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		HttpSession httpsession = request.getSession(false);
		String userid1 = request.getParameter("your_name1");
		System.out.println("XXXXXXXXXXXXX"+userid1);
		List<String> hivetableslist = new ArrayList<String>();
		Tru hdfsaccess = new Tru();
		try {
			hivetableslist=hdfsaccess.hdfsCommandInvoker("hadoop fs -ls /apps/hive/warehouse");
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		System.out.println("in run jobs ");
//		List<String> hivetables=new ArrayList<String>();
//		List<String> hivetableslist=new ArrayList<String>();
//			String command1="hadoop fs -ls /apps/hive/warehouse";
//		System.out.println("command1 "+command1);
//
//			String host="192.168.154.131";
//			String user="root";
//			String password="hbk4mask";
//			System.out.println("command1 "+command1);
//			try{
//
//				java.util.Properties config = new java.util.Properties(); 
//				config.put("StrictHostKeyChecking", "no");
//				JSch jsch = new JSch();
//				Session session=jsch.getSession(user, host, 22);
//				session.setPassword(password);
//				session.setConfig(config);
//				session.connect();
//				System.out.println("Connected");
//
//				Channel channel=session.openChannel("exec");
//				((ChannelExec)channel).setCommand(command1);
//				channel.setInputStream(null);
//				((ChannelExec)channel).setErrStream(System.err);
//
//				InputStream in=channel.getInputStream();
//				channel.connect();
//				byte[] tmp=new byte[1024];
//				while(true)
//				{
//					while(in.available()>0)
//					{
//						int i=in.read(tmp, 0, 1024);
//						if(i<0)break;
//						System.out.print(new String(tmp, 0, i));
//						hivetables.add(new String(tmp, 0, i));
//					}
//					if(channel.isClosed()){
//						System.out.println("exit-status: "+channel.getExitStatus());
//						break;
//					}
//					try{Thread.sleep(1000);}catch(Exception ee){}
//				}
//				channel.disconnect();
//				session.disconnect();
//				System.out.println("DONE");
//			}catch(Exception e){
//				e.printStackTrace();
//			}
//			for(String a:hivetables)
//			{			
//				
//				String[] table=a.split("drwxrwxrwx");
//				for(String b:table)
//				{
//					System.out.println("b  ***  "+b   );
//				String[] x=b.split("\\s+");
//				if(x.length>6)
//				{
//					System.out.println("x.length"+x.length);
//					String aa=x[3]+"    "+x[5]+"    "+x[7];
//					hivetableslist.add(aa);
//				}
//
//
//		} // if ends
//
//				for(String a1:hivetableslist)
//				{			
//					System.out.println(" table   "+a1);			
//				}
//				System.out.println("size ** "+hivetables.size()	);
//	}

			httpsession.setAttribute("li", hivetableslist);		
		request.getRequestDispatcher("/datafetch2.jsp").forward(request, response);
	}


	}


